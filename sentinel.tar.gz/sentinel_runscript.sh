#!/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/home/sibcoin
cd /home/sibcoin/sentinel && python2.7 bin/sentinel.py